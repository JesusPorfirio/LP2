﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;


namespace P0030481923037
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada = "";
            double[,] vendas = new double[9, 4];
            double resultado;
            double total = 0;
            Boolean stop=false;


            for (var x = 0; x < 7; x++)
            {

                resultado = 0;
                if (stop == true) { break; }
                for (var y = 0; y < 4; y++)
                {
                    entrada = Interaction.InputBox("Informe o valor: ", "mês " + (x + 1) + " Semana: " + (y+1));

                    if (entrada == "") 
                    { 
                        stop = true;
                        break;
                    }
                    if (double.TryParse(entrada, out vendas[x, y]))
                    {
                        lstbResultados.Items.Add("mês " + (x+1) + " semana " + (y+1)+ " >>> " + vendas[x, y].ToString("N2"));
                        resultado = vendas[x, y] + resultado;
                        total = total + vendas[x, y];
                    }
                    else
                    {
                        MessageBox.Show("Informe dados corretamente");
                        y--;
                    }
                    
                }
                lstbResultados.Items.Add(">>> total do mês " + resultado);
                lstbResultados.Items.Add("....................");
            }
            lstbResultados.Items.Add(" total geral >>> "+total.ToString("N2"));
        }

        private void bttClear_Click(object sender, EventArgs e)
        {
            lstbResultados.Items.Clear();
        }
    }
}
